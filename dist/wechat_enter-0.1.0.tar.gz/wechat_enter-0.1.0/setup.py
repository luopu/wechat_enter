from distutils.core import setup

setup(
    name='wechat_enter',
    version='0.1.0',
    packages=[''],
    url='http://pypi.python.org',
    license='MIT',
    author='luopu',
    author_email='pypi@luopu.me',
    description='微信企业号开发SDK'
)
